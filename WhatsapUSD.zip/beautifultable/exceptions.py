class BeautifulTableDeprecationWarning(DeprecationWarning):
    pass
