import requests
from collections import deque
from bs4 import BeautifulSoup

observables = ["USD", "EURO", "UF"]
observed_values = { value: deque([0 for _ in range(30)]) for value in observables }

to_float = lambda x: float(x.replace(",", ""))

def get_prices():

    # Valor usd, euro y uf
    page = requests.get("https://si3.bcentral.cl/Bdemovil/BDE/IndicadoresDiarios")
    soup = BeautifulSoup(page.content, 'html.parser')
    body = soup.body

    items_div = body.find_all(
            "table", class_="tableUnits")

    EURO = to_float(items_div[2].find("td", class_="col-xs-2").find("p").text)
    # print(f"EURO: ${EURO}")

    USD = to_float(items_div[1].find("td", class_="col-xs-2").find("p").text)
    # print(f"USD: ${USD}")

    UF = to_float(items_div[0].find("td", class_="col-xs-2").find("p").text)
    # print(f"UF: ${UF}")

    observed_values["EURO"].append(EURO)
    observed_values["EURO"].popleft()
    observed_values["USD"].append(USD)
    observed_values["USD"].popleft()
    observed_values["UF"].append(UF)
    observed_values["UF"].popleft()

